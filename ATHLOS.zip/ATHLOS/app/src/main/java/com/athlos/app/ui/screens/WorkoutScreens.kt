package com.athlos.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.athlos.app.domain.fmt
import com.athlos.app.domain.formatDuration
import com.athlos.app.ui.components.*
import com.athlos.app.ui.viewmodel.*

/** Pestaña "Entrenar": elegir qué rutina iniciar. */
@Composable
fun TrainScreen(onStart: (Long) -> Unit, onGoRoutines: () -> Unit) {
    val vm = athlosViewModel { RoutinesViewModel(it.repository) }
    val routines by vm.routines.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle("Entrenamiento", "Elige una rutina para empezar")
        if (routines.isEmpty()) {
            EmptyState("No hay rutinas", "Crea una rutina antes de entrenar.", actionLabel = "Ir a Rutinas", onAction = onGoRoutines)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(routines, key = { it.id }) { r ->
                    AthlosCard(Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(r.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("${r.exerciseCount} ejercicios", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Button(onClick = { onStart(r.id) }, enabled = r.exerciseCount > 0) { Text("Iniciar") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WorkoutScreen(routineId: Long, onClose: () -> Unit) {
    val vm = athlosViewModel { WorkoutViewModel(it.repository, routineId) }
    val s by vm.state.collectAsStateWithLifecycle()
    var confirmExit by remember { mutableStateOf(false) }

    BackHandler { if (s.finished) onClose() else confirmExit = true }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("¿Salir del entrenamiento?") },
            text = { Text("Se perderá el progreso que no hayas finalizado.") },
            confirmButton = { TextButton(onClick = onClose) { Text("Salir") } },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Continuar") } }
        )
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        when {
            s.loading -> CircularProgressIndicator()
            s.finished -> Summary(s, onClose)
            s.exercises.isEmpty() -> {
                SubHeader("Entrenamiento", onClose)
                EmptyState("Rutina vacía", s.error ?: "Esta rutina no tiene ejercicios.", actionLabel = "Volver", onAction = onClose)
            }
            else -> Active(s, vm, onExit = { confirmExit = true })
        }
    }
}

@Composable
private fun Summary(s: WorkoutUiState, onClose: () -> Unit) {
    ScreenTitle("¡Entrenamiento guardado!", s.routineName)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatCard("Series", "${s.completedSets}", Modifier.weight(1f))
        StatCard("Volumen (kg)", s.totalVolume.fmt(), Modifier.weight(1f))
        StatCard("Duración", formatDuration(s.elapsedSeconds), Modifier.weight(1f))
    }
    Spacer(Modifier.height(16.dp))
    Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Cerrar") }
}

@Composable
private fun ColumnScope.Active(s: WorkoutUiState, vm: WorkoutViewModel, onExit: () -> Unit) {
    val e = s.currentIndex
    val ex = s.exercises[e]

    SubHeader(s.routineName, onExit)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatCard("Tiempo", formatDuration(s.elapsedSeconds), Modifier.weight(1f))
        StatCard("Series", "${s.completedSets}/${s.totalSets}", Modifier.weight(1f))
        StatCard("Volumen (kg)", s.totalVolume.fmt(), Modifier.weight(1f))
    }
    Spacer(Modifier.height(8.dp))

    if (s.restRemaining > 0) {
        AthlosCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Descanso", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(formatDuration(s.restRemaining), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                }
                OutlinedButton(onClick = vm::skipRest) { Text("Saltar") }
            }
        }
        Spacer(Modifier.height(8.dp))
    }

    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Ejercicio ${e + 1} de ${s.exercises.size}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(ex.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        ex.sets.forEachIndexed { j, set ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("S${j + 1}", Modifier.width(32.dp), fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = set.weight,
                    onValueChange = { vm.setWeight(e, j, it) },
                    label = { Text("kg") },
                    singleLine = true,
                    enabled = !set.done,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = set.reps,
                    onValueChange = { vm.setReps(e, j, it.filter(Char::isDigit)) },
                    label = { Text("reps") },
                    singleLine = true,
                    enabled = !set.done,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { vm.toggleSet(e, j) }) {
                    Icon(
                        Icons.Filled.CheckCircle,
                        contentDescription = if (set.done) "Desmarcar serie" else "Completar serie",
                        tint = if (set.done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                    )
                }
            }
        }
        TextButton(onClick = { vm.addSet(e) }) { Text("+ Añadir serie") }
    }

    ErrorText(s.error)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = vm::previous, enabled = e > 0, modifier = Modifier.weight(1f)) { Text("Anterior") }
        OutlinedButton(onClick = vm::next, enabled = e < s.exercises.size - 1, modifier = Modifier.weight(1f)) { Text("Siguiente") }
    }
    Spacer(Modifier.height(8.dp))
    Button(onClick = vm::finish, enabled = !s.saving, modifier = Modifier.fillMaxWidth()) {
        Text(if (s.saving) "Guardando…" else "Finalizar entrenamiento")
    }
}
