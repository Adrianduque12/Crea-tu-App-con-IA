package com.athlos.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.athlos.app.data.AthlosRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class HistoryItem(
    val id: Long,
    val routineName: String,
    val startedAt: Long,
    val durationSeconds: Int,
    val sets: Int,
    val volume: Double
)

data class ExerciseRecord(
    val exerciseId: Long,
    val name: String,
    val maxWeight: Double,
    val bestSetVolume: Double,
    val weightBySession: List<Float>
)

data class ProgressUi(
    val sessions: Int = 0,
    val totalVolume: Double = 0.0,
    val totalSets: Int = 0,
    val history: List<HistoryItem> = emptyList(),
    val records: List<ExerciseRecord> = emptyList()
)

class ProgressViewModel(repo: AthlosRepository) : ViewModel() {
    val ui: StateFlow<ProgressUi> = combine(repo.workouts, repo.sets) { workouts, sets ->
        val byWorkout = sets.groupBy { it.workoutId }
        val dateOf = workouts.associate { it.id to it.startedAt }

        val history = workouts.map { w ->
            val mine = byWorkout[w.id].orEmpty()
            HistoryItem(w.id, w.routineName, w.startedAt, w.durationSeconds, mine.size, mine.sumOf { it.weight * it.reps })
        }

        val records = sets.groupBy { it.exerciseId }.map { (exId, list) ->
            val perSession = list.groupBy { it.workoutId }
                .map { (wid, ss) -> (dateOf[wid] ?: 0L) to ss.maxOf { it.weight }.toFloat() }
                .sortedBy { it.first }
                .map { it.second }
            ExerciseRecord(
                exerciseId = exId,
                name = list.first().exerciseName,
                maxWeight = list.maxOf { it.weight },
                bestSetVolume = list.maxOf { it.weight * it.reps },
                weightBySession = perSession
            )
        }.sortedBy { it.name }

        ProgressUi(
            sessions = workouts.size,
            totalVolume = sets.sumOf { it.weight * it.reps },
            totalSets = sets.size,
            history = history,
            records = records
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ProgressUi())
}
