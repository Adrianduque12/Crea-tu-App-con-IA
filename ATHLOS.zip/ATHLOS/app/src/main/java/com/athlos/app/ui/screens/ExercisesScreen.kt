package com.athlos.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.athlos.app.data.SeedData
import com.athlos.app.ui.components.*
import com.athlos.app.ui.viewmodel.ExercisesViewModel
import com.athlos.app.ui.viewmodel.athlosViewModel

@Composable
fun ExercisesScreen() {
    val vm = athlosViewModel { ExercisesViewModel(it.repository) }
    val exercises by vm.exercises.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val group by vm.group.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle("Ejercicios", "Catálogo por grupo muscular")
        OutlinedTextField(
            value = query,
            onValueChange = { vm.query.value = it },
            label = { Text("Buscar ejercicio") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(selected = group == null, onClick = { vm.group.value = null }, label = { Text("Todos") }) }
            items(SeedData.muscleGroups) { g ->
                FilterChip(selected = group == g, onClick = { vm.group.value = g }, label = { Text(g) })
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { vm.clearError(); showAdd = true }) { Text("+ Nuevo ejercicio") }
        Spacer(Modifier.height(8.dp))

        if (exercises.isEmpty()) {
            EmptyState("Sin resultados", "Prueba con otro nombre o grupo muscular.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(exercises, key = { it.id }) { ex ->
                    AthlosCard(Modifier.fillMaxWidth()) {
                        Text(ex.name, fontWeight = FontWeight.Bold)
                        Text(ex.muscleGroup, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    if (showAdd) {
        var name by remember { mutableStateOf("") }
        var g by remember { mutableStateOf(SeedData.muscleGroups.first()) }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Nuevo ejercicio") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nombre") }, singleLine = true)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(SeedData.muscleGroups) { m ->
                            FilterChip(selected = g == m, onClick = { g = m }, label = { Text(m) })
                        }
                    }
                    ErrorText(error)
                }
            },
            confirmButton = { TextButton(onClick = { vm.add(name, g) { showAdd = false } }) { Text("Guardar") } },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancelar") } }
        )
    }
}
