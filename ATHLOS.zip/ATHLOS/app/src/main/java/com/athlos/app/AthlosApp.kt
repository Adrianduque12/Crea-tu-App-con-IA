package com.athlos.app

import android.app.Application
import com.athlos.app.data.AppContainer

class AthlosApp : Application() {
    val container: AppContainer by lazy { AppContainer(this) }
}
