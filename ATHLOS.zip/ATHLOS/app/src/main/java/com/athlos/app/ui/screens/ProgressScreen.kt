package com.athlos.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.athlos.app.domain.fmt
import com.athlos.app.domain.formatDate
import com.athlos.app.domain.formatDuration
import com.athlos.app.ui.components.*
import com.athlos.app.ui.viewmodel.*

@Composable
fun ProgressScreen() {
    val vm = athlosViewModel { ProgressViewModel(it.repository) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    var selectedId by remember { mutableStateOf<Long?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle("Progreso", "Basado en tus entrenamientos guardados")
        if (ui.sessions == 0) {
            EmptyState("Todavía no hay datos", "Completa un entrenamiento y aquí verás tu volumen, historial y récords.")
            return@Column
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("Sesiones", "${ui.sessions}", Modifier.weight(1f))
                    StatCard("Series", "${ui.totalSets}", Modifier.weight(1f))
                    StatCard("Volumen (kg)", ui.totalVolume.fmt(), Modifier.weight(1f))
                }
            }
            if (ui.records.isNotEmpty()) {
                val selected = ui.records.firstOrNull { it.exerciseId == selectedId } ?: ui.records.first()
                item { Text("Evolución y récords", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ui.records, key = { it.exerciseId }) { r ->
                            FilterChip(selected = r.exerciseId == selected.exerciseId, onClick = { selectedId = r.exerciseId }, label = { Text(r.name) })
                        }
                    }
                }
                item {
                    AthlosCard(Modifier.fillMaxWidth()) {
                        Text(selected.name, fontWeight = FontWeight.Bold)
                        Text("Peso máximo por sesión (kg)", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(8.dp))
                        LineChart(selected.weightBySession)
                        Spacer(Modifier.height(8.dp))
                        Text("Récord de peso: ${selected.maxWeight.fmt()} kg", color = MaterialTheme.colorScheme.primary)
                        Text("Mejor serie (volumen): ${selected.bestSetVolume.fmt()} kg")
                        if (selected.weightBySession.size < 2) {
                            Text("Registra más sesiones para ver la evolución.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item { Text("Historial", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(ui.history, key = { it.id }) { h ->
                AthlosCard(Modifier.fillMaxWidth()) {
                    Text(h.routineName, fontWeight = FontWeight.Bold)
                    Text(formatDate(h.startedAt), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    Text("${h.sets} series · ${h.volume.fmt()} kg · ${formatDuration(h.durationSeconds)}")
                }
            }
        }
    }
}
