package com.athlos.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.athlos.app.data.AthlosRepository
import com.athlos.app.data.SetLogEntity
import com.athlos.app.data.WorkoutEntity
import com.athlos.app.domain.WorkoutCalculator
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SetUi(val weight: String = "", val reps: String, val done: Boolean = false)

data class ExerciseUi(val exerciseId: Long, val name: String, val restSeconds: Int, val sets: List<SetUi>)

data class WorkoutUiState(
    val loading: Boolean = true,
    val routineName: String = "",
    val exercises: List<ExerciseUi> = emptyList(),
    val currentIndex: Int = 0,
    val elapsedSeconds: Int = 0,
    val restRemaining: Int = 0,
    val error: String? = null,
    val saving: Boolean = false,
    val finished: Boolean = false
) {
    val totalSets: Int get() = exercises.sumOf { it.sets.size }
    val completedSets: Int get() = exercises.sumOf { ex -> ex.sets.count { it.done } }
    val totalVolume: Double
        get() = exercises.sumOf { ex ->
            ex.sets.filter { it.done }.sumOf { s ->
                val w = WorkoutCalculator.parseWeight(s.weight)
                val r = WorkoutCalculator.parseReps(s.reps)
                if (w != null && r != null) WorkoutCalculator.setVolume(w, r) else 0.0
            }
        }
}

class WorkoutViewModel(private val repo: AthlosRepository, private val routineId: Long) : ViewModel() {
    private val _state = MutableStateFlow(WorkoutUiState())
    val state: StateFlow<WorkoutUiState> = _state.asStateFlow()
    private val startedAt = System.currentTimeMillis()

    init {
        load()
        startTimer()
    }

    private fun load() {
        viewModelScope.launch {
            runCatching { repo.getRoutine(routineId) to repo.getItems(routineId) }
                .onSuccess { (routine, items) ->
                    _state.update {
                        it.copy(
                            loading = false,
                            routineName = routine?.name ?: "",
                            exercises = items.map { i ->
                                ExerciseUi(i.exerciseId, i.name, i.restSeconds, List(i.sets) { SetUi(reps = i.reps.toString()) })
                            }
                        )
                    }
                }
                .onFailure { _state.update { it.copy(loading = false, error = "No se pudo cargar la rutina.") } }
        }
    }

    private fun startTimer() {
        viewModelScope.launch {
            while (true) {
                delay(1000)
                _state.update {
                    if (it.loading || it.finished) it
                    else it.copy(elapsedSeconds = it.elapsedSeconds + 1, restRemaining = (it.restRemaining - 1).coerceAtLeast(0))
                }
            }
        }
    }

    private fun modifySet(e: Int, s: Int, f: (SetUi) -> SetUi) = _state.update { st ->
        st.copy(
            error = null,
            exercises = st.exercises.mapIndexed { i, ex ->
                if (i != e) ex else ex.copy(sets = ex.sets.mapIndexed { j, set -> if (j == s) f(set) else set })
            }
        )
    }

    fun setWeight(e: Int, s: Int, text: String) = modifySet(e, s) { it.copy(weight = text) }
    fun setReps(e: Int, s: Int, text: String) = modifySet(e, s) { it.copy(reps = text) }

    fun toggleSet(e: Int, s: Int) {
        val st = _state.value
        val set = st.exercises.getOrNull(e)?.sets?.getOrNull(s) ?: return
        if (set.done) {
            modifySet(e, s) { it.copy(done = false) }
            return
        }
        if (WorkoutCalculator.parseWeight(set.weight) == null) {
            _state.update { it.copy(error = "Serie ${s + 1}: introduce un peso válido (0 o mayor).") }
            return
        }
        if (WorkoutCalculator.parseReps(set.reps) == null) {
            _state.update { it.copy(error = "Serie ${s + 1}: las repeticiones deben ser un entero mayor que 0.") }
            return
        }
        modifySet(e, s) { it.copy(done = true) }
        _state.update { it.copy(restRemaining = it.exercises[e].restSeconds) }
    }

    fun addSet(e: Int) = _state.update { st ->
        st.copy(exercises = st.exercises.mapIndexed { i, ex ->
            if (i != e) ex else ex.copy(sets = ex.sets + SetUi(weight = ex.sets.lastOrNull()?.weight ?: "", reps = ex.sets.lastOrNull()?.reps ?: "10"))
        })
    }

    fun goTo(index: Int) = _state.update { it.copy(currentIndex = index.coerceIn(0, (it.exercises.size - 1).coerceAtLeast(0))) }
    fun next() = goTo(_state.value.currentIndex + 1)
    fun previous() = goTo(_state.value.currentIndex - 1)
    fun skipRest() = _state.update { it.copy(restRemaining = 0) }

    fun finish() {
        val st = _state.value
        if (st.saving || st.finished) return
        val logs = mutableListOf<SetLogEntity>()
        st.exercises.forEach { ex ->
            ex.sets.forEachIndexed { idx, s ->
                if (s.done) {
                    val w = WorkoutCalculator.parseWeight(s.weight)
                    val r = WorkoutCalculator.parseReps(s.reps)
                    if (w != null && r != null) {
                        logs += SetLogEntity(workoutId = 0, exerciseId = ex.exerciseId, exerciseName = ex.name, setNumber = idx + 1, weight = w, reps = r)
                    }
                }
            }
        }
        if (logs.isEmpty()) {
            _state.update { it.copy(error = "Completa al menos una serie antes de finalizar.") }
            return
        }
        _state.update { it.copy(saving = true, error = null) }
        viewModelScope.launch {
            runCatching {
                repo.saveWorkout(WorkoutEntity(routineName = st.routineName, startedAt = startedAt, durationSeconds = st.elapsedSeconds), logs)
            }.onSuccess {
                _state.update { it.copy(saving = false, finished = true, restRemaining = 0) }
            }.onFailure {
                _state.update { it.copy(saving = false, error = "No se pudo guardar el entrenamiento. Inténtalo de nuevo.") }
            }
        }
    }
}
