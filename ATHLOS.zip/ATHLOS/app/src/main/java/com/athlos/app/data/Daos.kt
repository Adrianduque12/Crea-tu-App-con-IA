package com.athlos.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ExerciseDao {
    @Query("SELECT * FROM exercises ORDER BY name")
    fun observeAll(): Flow<List<ExerciseEntity>>

    @Query("SELECT COUNT(*) FROM exercises")
    suspend fun count(): Int

    @Insert
    suspend fun insert(exercise: ExerciseEntity): Long

    @Insert
    suspend fun insertAll(list: List<ExerciseEntity>)
}

@Dao
interface RoutineDao {
    @Query(
        "SELECT r.id AS id, r.name AS name, " +
            "(SELECT COUNT(*) FROM routine_exercises WHERE routineId = r.id) AS exerciseCount " +
            "FROM routines r ORDER BY r.name"
    )
    fun observeSummaries(): Flow<List<RoutineSummary>>

    @Query("SELECT * FROM routines WHERE id = :id")
    suspend fun getRoutine(id: Long): RoutineEntity?

    @Insert
    suspend fun insertRoutine(routine: RoutineEntity): Long

    @Update
    suspend fun updateRoutine(routine: RoutineEntity)

    @Query("DELETE FROM routines WHERE id = :id")
    suspend fun deleteRoutine(id: Long)

    @Query(
        "SELECT re.exerciseId AS exerciseId, e.name AS name, e.muscleGroup AS muscleGroup, " +
            "re.sets AS sets, re.reps AS reps, re.restSeconds AS restSeconds " +
            "FROM routine_exercises re INNER JOIN exercises e ON e.id = re.exerciseId " +
            "WHERE re.routineId = :routineId ORDER BY re.id"
    )
    suspend fun getItems(routineId: Long): List<RoutineItem>

    @Insert
    suspend fun insertItems(items: List<RoutineExerciseEntity>)

    @Query("DELETE FROM routine_exercises WHERE routineId = :routineId")
    suspend fun deleteItems(routineId: Long)
}

@Dao
interface WorkoutDao {
    @Insert
    suspend fun insertWorkout(workout: WorkoutEntity): Long

    @Insert
    suspend fun insertSets(sets: List<SetLogEntity>)

    @Query("SELECT * FROM workouts ORDER BY startedAt DESC")
    fun observeWorkouts(): Flow<List<WorkoutEntity>>

    @Query("SELECT * FROM set_logs")
    fun observeSets(): Flow<List<SetLogEntity>>
}
