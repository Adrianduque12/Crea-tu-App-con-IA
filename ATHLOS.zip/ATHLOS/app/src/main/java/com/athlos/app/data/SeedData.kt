package com.athlos.app.data

object SeedData {
    val muscleGroups = listOf("Pecho", "Espalda", "Piernas", "Hombros", "Brazos", "Core")

    val exercises = listOf(
        ExerciseEntity(name = "Press banca", muscleGroup = "Pecho"),
        ExerciseEntity(name = "Press inclinado con mancuernas", muscleGroup = "Pecho"),
        ExerciseEntity(name = "Aperturas con mancuernas", muscleGroup = "Pecho"),
        ExerciseEntity(name = "Fondos en paralelas", muscleGroup = "Pecho"),
        ExerciseEntity(name = "Dominadas", muscleGroup = "Espalda"),
        ExerciseEntity(name = "Remo con barra", muscleGroup = "Espalda"),
        ExerciseEntity(name = "Jalón al pecho", muscleGroup = "Espalda"),
        ExerciseEntity(name = "Peso muerto", muscleGroup = "Espalda"),
        ExerciseEntity(name = "Sentadilla", muscleGroup = "Piernas"),
        ExerciseEntity(name = "Prensa de piernas", muscleGroup = "Piernas"),
        ExerciseEntity(name = "Peso muerto rumano", muscleGroup = "Piernas"),
        ExerciseEntity(name = "Zancadas", muscleGroup = "Piernas"),
        ExerciseEntity(name = "Elevación de gemelos", muscleGroup = "Piernas"),
        ExerciseEntity(name = "Press militar", muscleGroup = "Hombros"),
        ExerciseEntity(name = "Elevaciones laterales", muscleGroup = "Hombros"),
        ExerciseEntity(name = "Pájaros", muscleGroup = "Hombros"),
        ExerciseEntity(name = "Curl de bíceps", muscleGroup = "Brazos"),
        ExerciseEntity(name = "Curl martillo", muscleGroup = "Brazos"),
        ExerciseEntity(name = "Extensión de tríceps en polea", muscleGroup = "Brazos"),
        ExerciseEntity(name = "Press francés", muscleGroup = "Brazos"),
        ExerciseEntity(name = "Plancha (repeticiones = segundos)", muscleGroup = "Core"),
        ExerciseEntity(name = "Crunch abdominal", muscleGroup = "Core"),
        ExerciseEntity(name = "Elevación de piernas", muscleGroup = "Core")
    )
}
