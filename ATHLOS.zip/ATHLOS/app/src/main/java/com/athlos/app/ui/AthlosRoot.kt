package com.athlos.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.athlos.app.ui.screens.*

enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "Inicio", Icons.Filled.Home),
    Routines("routines", "Rutinas", Icons.AutoMirrored.Filled.List),
    Train("train", "Entrenar", Icons.Filled.PlayArrow),
    Exercises("exercises", "Ejercicios", Icons.Filled.Search),
    Progress("progress", "Progreso", Icons.Filled.DateRange),
    Profile("profile", "Perfil", Icons.Filled.Person)
}

private const val ROUTINE_EDIT = "routine_edit/{id}"
private const val WORKOUT = "workout/{id}"

private fun NavHostController.goTab(route: String) {
    navigate(route) {
        popUpTo(Tab.Home.route) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun AthlosRoot() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route
    val showBar = Tab.entries.any { it.route == current }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    Tab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = current == tab.route,
                            onClick = { nav.goTab(tab.route) },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label, fontSize = 10.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.Black,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primary,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(nav, startDestination = Tab.Home.route, modifier = Modifier.padding(padding)) {
            composable(Tab.Home.route) { HomeScreen(onStartTraining = { nav.goTab(Tab.Train.route) }) }
            composable(Tab.Routines.route) {
                RoutinesScreen(onNew = { nav.navigate("routine_edit/-1") }, onEdit = { nav.navigate("routine_edit/$it") })
            }
            composable(Tab.Train.route) {
                TrainScreen(onStart = { nav.navigate("workout/$it") }, onGoRoutines = { nav.goTab(Tab.Routines.route) })
            }
            composable(Tab.Exercises.route) { ExercisesScreen() }
            composable(Tab.Progress.route) { ProgressScreen() }
            composable(Tab.Profile.route) { ProfileScreen() }
            composable(ROUTINE_EDIT, arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                RoutineEditScreen(e.arguments?.getLong("id") ?: -1L, onBack = { nav.popBackStack() })
            }
            composable(WORKOUT, arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                WorkoutScreen(e.arguments?.getLong("id") ?: -1L, onClose = { nav.popBackStack() })
            }
        }
    }
}
