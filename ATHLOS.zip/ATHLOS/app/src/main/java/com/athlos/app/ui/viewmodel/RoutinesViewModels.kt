package com.athlos.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.athlos.app.data.AthlosRepository
import com.athlos.app.data.ExerciseEntity
import com.athlos.app.data.RoutineExerciseEntity
import com.athlos.app.data.RoutineSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class RoutinesViewModel(private val repo: AthlosRepository) : ViewModel() {
    val routines: StateFlow<List<RoutineSummary>> =
        repo.routines.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val error = MutableStateFlow<String?>(null)

    fun delete(id: Long) {
        viewModelScope.launch {
            runCatching { repo.deleteRoutine(id) }
                .onFailure { error.value = "No se pudo eliminar la rutina." }
        }
    }
}

data class EditItem(
    val exerciseId: Long,
    val name: String,
    val group: String,
    val sets: String = "3",
    val reps: String = "10",
    val rest: String = "90"
)

data class RoutineEditUi(
    val loading: Boolean = true,
    val name: String = "",
    val items: List<EditItem> = emptyList(),
    val error: String? = null,
    val saved: Boolean = false
)

class RoutineEditViewModel(private val repo: AthlosRepository, private val routineId: Long) : ViewModel() {
    private val _ui = MutableStateFlow(RoutineEditUi())
    val ui: StateFlow<RoutineEditUi> = _ui.asStateFlow()

    val exercises: StateFlow<List<ExerciseEntity>> =
        repo.exercises.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        if (routineId > 0) load() else _ui.update { it.copy(loading = false) }
    }

    private fun load() {
        viewModelScope.launch {
            runCatching { repo.getRoutine(routineId) to repo.getItems(routineId) }
                .onSuccess { (routine, items) ->
                    _ui.update {
                        it.copy(
                            loading = false,
                            name = routine?.name ?: "",
                            items = items.map { i ->
                                EditItem(i.exerciseId, i.name, i.muscleGroup, i.sets.toString(), i.reps.toString(), i.restSeconds.toString())
                            }
                        )
                    }
                }
                .onFailure { _ui.update { it.copy(loading = false, error = "No se pudo cargar la rutina.") } }
        }
    }

    fun setName(v: String) = _ui.update { it.copy(name = v, error = null) }

    fun addExercise(e: ExerciseEntity) = _ui.update { st ->
        if (st.items.any { it.exerciseId == e.id }) st.copy(error = "Ese ejercicio ya está en la rutina.")
        else st.copy(items = st.items + EditItem(e.id, e.name, e.muscleGroup), error = null)
    }

    fun removeItem(index: Int) = _ui.update { st -> st.copy(items = st.items.filterIndexed { i, _ -> i != index }) }

    private fun modify(index: Int, f: (EditItem) -> EditItem) = _ui.update { st ->
        st.copy(error = null, items = st.items.mapIndexed { i, item -> if (i == index) f(item) else item })
    }

    fun setSets(index: Int, v: String) = modify(index) { it.copy(sets = v.filter(Char::isDigit)) }
    fun setReps(index: Int, v: String) = modify(index) { it.copy(reps = v.filter(Char::isDigit)) }
    fun setRest(index: Int, v: String) = modify(index) { it.copy(rest = v.filter(Char::isDigit)) }

    fun save() {
        val st = _ui.value
        val name = st.name.trim()
        if (name.isEmpty()) { fail("El nombre de la rutina es obligatorio."); return }
        if (st.items.isEmpty()) { fail("Añade al menos un ejercicio."); return }
        val entities = mutableListOf<RoutineExerciseEntity>()
        for (item in st.items) {
            val sets = item.sets.toIntOrNull()
            val reps = item.reps.toIntOrNull()
            val rest = item.rest.toIntOrNull()
            if (sets == null || sets <= 0 || reps == null || reps <= 0 || rest == null || rest < 0) {
                fail("Revisa «${item.name}»: series y repeticiones deben ser mayores que 0 y el descanso 0 o más.")
                return
            }
            entities += RoutineExerciseEntity(routineId = 0, exerciseId = item.exerciseId, sets = sets, reps = reps, restSeconds = rest)
        }
        viewModelScope.launch {
            runCatching { repo.saveRoutine(if (routineId > 0) routineId else null, name, entities) }
                .onSuccess { _ui.update { it.copy(saved = true) } }
                .onFailure { fail("No se pudo guardar la rutina.") }
        }
    }

    private fun fail(msg: String) = _ui.update { it.copy(error = msg) }
}
