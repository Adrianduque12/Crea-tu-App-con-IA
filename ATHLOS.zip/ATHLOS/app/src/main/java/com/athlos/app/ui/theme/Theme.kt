package com.athlos.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Lime = Color(0xFFB6F500)
val Carbon = Color(0xFF0B0B0B)
val SurfaceDark = Color(0xFF141414)
val CardDark = Color(0xFF222222)
val OutlineDark = Color(0xFF3A3A3A)
val TextPrimary = Color(0xFFF2F2F2)
val TextSecondary = Color(0xFF9A9A9A)
val ErrorRed = Color(0xFFFF6B6B)

private val AthlosColors = darkColorScheme(
    primary = Lime,
    onPrimary = Color.Black,
    secondary = Lime,
    background = Carbon,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = CardDark,
    onSurfaceVariant = TextSecondary,
    outline = OutlineDark,
    error = ErrorRed
)

@Composable
fun AthlosTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AthlosColors, content = content)
}
