package com.athlos.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.athlos.app.data.AthlosRepository
import com.athlos.app.data.ProfileStore
import com.athlos.app.domain.startOfWeek
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class HomeUi(
    val name: String = "",
    val goal: Int = 3,
    val weekSessions: Int = 0,
    val totalSessions: Int = 0,
    val last: HistoryItem? = null
)

class HomeViewModel(repo: AthlosRepository, profile: ProfileStore) : ViewModel() {
    val ui: StateFlow<HomeUi> = combine(repo.workouts, repo.sets, profile.name, profile.weeklyGoal) { ws, ss, name, goal ->
        val weekStart = startOfWeek()
        val last = ws.firstOrNull()
        HomeUi(
            name = name,
            goal = goal,
            weekSessions = ws.count { it.startedAt >= weekStart },
            totalSessions = ws.size,
            last = last?.let { w ->
                val mine = ss.filter { it.workoutId == w.id }
                HistoryItem(w.id, w.routineName, w.startedAt, w.durationSeconds, mine.size, mine.sumOf { it.weight * it.reps })
            }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUi())
}

class ProfileViewModel(private val profile: ProfileStore) : ViewModel() {
    val name = profile.name
    val goal = profile.weeklyGoal
    fun save(name: String, goal: Int) = profile.save(name.trim(), goal.coerceIn(1, 7))
}
