package com.athlos.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.athlos.app.ui.components.*
import com.athlos.app.ui.viewmodel.*

@Composable
fun RoutinesScreen(onNew: () -> Unit, onEdit: (Long) -> Unit) {
    val vm = athlosViewModel { RoutinesViewModel(it.repository) }
    val routines by vm.routines.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    var toDelete by remember { mutableStateOf<Long?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle("Rutinas", "Crea y edita tus planes")
        Button(onClick = onNew, modifier = Modifier.fillMaxWidth()) { Text("Nueva rutina") }
        ErrorText(error)
        Spacer(Modifier.height(12.dp))
        if (routines.isEmpty()) {
            EmptyState("No tienes rutinas", "Crea tu primera rutina para empezar a entrenar.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(routines, key = { it.id }) { r ->
                    AthlosCard(Modifier.fillMaxWidth(), onClick = { onEdit(r.id) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(r.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("${r.exerciseCount} ejercicios", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { onEdit(r.id) }) { Icon(Icons.Filled.Edit, "Editar") }
                            IconButton(onClick = { toDelete = r.id }) { Icon(Icons.Filled.Delete, "Eliminar") }
                        }
                    }
                }
            }
        }
    }

    toDelete?.let { id ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("¿Eliminar rutina?") },
            text = { Text("Esta acción no se puede deshacer. El historial de entrenamientos se conserva.") },
            confirmButton = { TextButton(onClick = { vm.delete(id); toDelete = null }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun RoutineEditScreen(routineId: Long, onBack: () -> Unit) {
    val vm = athlosViewModel { RoutineEditViewModel(it.repository, routineId) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val allExercises by vm.exercises.collectAsStateWithLifecycle()
    var showPicker by remember { mutableStateOf(false) }

    LaunchedEffect(ui.saved) { if (ui.saved) onBack() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        SubHeader(if (routineId > 0) "Editar rutina" else "Nueva rutina", onBack)
        if (ui.loading) {
            CircularProgressIndicator()
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    OutlinedTextField(
                        value = ui.name,
                        onValueChange = vm::setName,
                        label = { Text("Nombre de la rutina") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                itemsIndexed(ui.items, key = { _, row -> row.exerciseId }) { index, item ->
                    AthlosCard(Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(item.name, fontWeight = FontWeight.Bold)
                                Text(item.group, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { vm.removeItem(index) }) { Icon(Icons.Filled.Delete, "Quitar") }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NumberField("Series", item.sets, { vm.setSets(index, it) }, Modifier.weight(1f))
                            NumberField("Reps", item.reps, { vm.setReps(index, it) }, Modifier.weight(1f))
                            NumberField("Descanso (s)", item.rest, { vm.setRest(index, it) }, Modifier.weight(1f))
                        }
                    }
                }
                item {
                    OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Añadir ejercicio") }
                }
            }
            ErrorText(ui.error)
            Button(onClick = vm::save, modifier = Modifier.fillMaxWidth()) { Text("Guardar rutina") }
        }
    }

    if (showPicker) {
        var q by remember { mutableStateOf("") }
        val filtered = allExercises.filter { it.name.contains(q.trim(), ignoreCase = true) }
        AlertDialog(
            onDismissRequest = { showPicker = false },
            title = { Text("Añadir ejercicio") },
            text = {
                Column {
                    OutlinedTextField(value = q, onValueChange = { q = it }, label = { Text("Buscar") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.heightIn(max = 320.dp)) {
                        items(filtered, key = { it.id }) { e ->
                            TextButton(onClick = { vm.addExercise(e); showPicker = false }, modifier = Modifier.fillMaxWidth()) {
                                Text("${e.name} · ${e.muscleGroup}", modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPicker = false }) { Text("Cerrar") } }
        )
    }
}

@Composable
fun NumberField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label, maxLines = 1) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier
    )
}
