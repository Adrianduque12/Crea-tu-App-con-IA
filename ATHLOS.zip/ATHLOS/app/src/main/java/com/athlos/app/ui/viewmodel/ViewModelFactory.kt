package com.athlos.app.ui.viewmodel

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.athlos.app.AthlosApp
import com.athlos.app.data.AppContainer

@Composable
inline fun <reified VM : ViewModel> athlosViewModel(crossinline create: (AppContainer) -> VM): VM {
    val app = LocalContext.current.applicationContext as AthlosApp
    return viewModel(factory = viewModelFactory { initializer { create(app.container) } })
}
