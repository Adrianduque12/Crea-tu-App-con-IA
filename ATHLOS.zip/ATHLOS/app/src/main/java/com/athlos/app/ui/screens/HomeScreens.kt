package com.athlos.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.athlos.app.domain.fmt
import com.athlos.app.domain.formatDate
import com.athlos.app.domain.formatDuration
import com.athlos.app.ui.components.*
import com.athlos.app.ui.viewmodel.*

@Composable
fun HomeScreen(onStartTraining: () -> Unit) {
    val vm = athlosViewModel { HomeViewModel(it.repository, it.profile) }
    val ui by vm.ui.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenTitle(
            title = if (ui.name.isBlank()) "Hola" else "Hola, ${ui.name}",
            subtitle = "Listo para entrenar"
        )
        AthlosCard(Modifier.fillMaxWidth()) {
            Text("Objetivo semanal", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("${ui.weekSessions} / ${ui.goal} sesiones", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { (ui.weekSessions.toFloat() / ui.goal.coerceAtLeast(1)).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.outline
            )
        }
        Button(onClick = onStartTraining, modifier = Modifier.fillMaxWidth()) { Text("Empezar entrenamiento") }

        Text("Último entrenamiento", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        val last = ui.last
        if (last == null) {
            AthlosCard(Modifier.fillMaxWidth()) {
                EmptyState("Aún no hay entrenamientos", "Cuando completes tu primera sesión aparecerá aquí.")
            }
        } else {
            AthlosCard(Modifier.fillMaxWidth()) {
                Text(last.routineName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(formatDate(last.startedAt), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Text("${last.sets} series · ${last.volume.fmt()} kg de volumen · ${formatDuration(last.durationSeconds)}")
            }
        }
        Text("Sesiones totales: ${ui.totalSessions}", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun ProfileScreen() {
    val vm = athlosViewModel { ProfileViewModel(it.profile) }
    val savedName by vm.name.collectAsStateWithLifecycle()
    val savedGoal by vm.goal.collectAsStateWithLifecycle()
    var name by remember(savedName) { mutableStateOf(savedName) }
    var goal by remember(savedGoal) { mutableIntStateOf(savedGoal) }
    var saved by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenTitle("Perfil", "Tus datos se guardan en el dispositivo")
        OutlinedTextField(
            value = name,
            onValueChange = { name = it; saved = false },
            label = { Text("Nombre") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        AthlosCard(Modifier.fillMaxWidth()) {
            Text("Objetivo semanal (sesiones)", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                OutlinedButton(onClick = { goal = (goal - 1).coerceAtLeast(1); saved = false }) { Text("−") }
                Text("$goal", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                OutlinedButton(onClick = { goal = (goal + 1).coerceAtMost(7); saved = false }) { Text("+") }
            }
        }
        Button(onClick = { vm.save(name, goal); saved = true }, modifier = Modifier.fillMaxWidth()) { Text("Guardar") }
        if (saved) Text("Perfil guardado", color = MaterialTheme.colorScheme.primary)
    }
}
