package com.athlos.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Nombre y objetivo semanal guardados en SharedPreferences (suficiente para 2 valores simples). */
class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("athlos_profile", Context.MODE_PRIVATE)
    private val _name = MutableStateFlow(prefs.getString("name", "") ?: "")
    private val _goal = MutableStateFlow(prefs.getInt("weekly_goal", 3))

    val name: StateFlow<String> = _name
    val weeklyGoal: StateFlow<Int> = _goal

    fun save(name: String, goal: Int) {
        prefs.edit().putString("name", name).putInt("weekly_goal", goal).apply()
        _name.value = name
        _goal.value = goal
    }
}
