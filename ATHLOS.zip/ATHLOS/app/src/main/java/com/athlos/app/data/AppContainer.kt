package com.athlos.app.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Contenedor manual de dependencias (sin Hilt, para mantenerlo simple). */
class AppContainer(context: Context) {
    private val db = AthlosDatabase.build(context)
    val repository = AthlosRepository(db)
    val profile = ProfileStore(context)

    init {
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            runCatching { repository.seedIfEmpty() }
        }
    }
}
