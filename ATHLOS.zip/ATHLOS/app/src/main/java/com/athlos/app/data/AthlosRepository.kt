package com.athlos.app.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow

/** Único punto de acceso a datos para toda la app. */
class AthlosRepository(private val db: AthlosDatabase) {
    private val exerciseDao = db.exerciseDao()
    private val routineDao = db.routineDao()
    private val workoutDao = db.workoutDao()

    val exercises: Flow<List<ExerciseEntity>> = exerciseDao.observeAll()
    val routines: Flow<List<RoutineSummary>> = routineDao.observeSummaries()
    val workouts: Flow<List<WorkoutEntity>> = workoutDao.observeWorkouts()
    val sets: Flow<List<SetLogEntity>> = workoutDao.observeSets()

    suspend fun seedIfEmpty() {
        if (exerciseDao.count() == 0) exerciseDao.insertAll(SeedData.exercises)
    }

    suspend fun addExercise(name: String, group: String) {
        exerciseDao.insert(ExerciseEntity(name = name, muscleGroup = group))
    }

    suspend fun getRoutine(id: Long): RoutineEntity? = routineDao.getRoutine(id)

    suspend fun getItems(routineId: Long): List<RoutineItem> = routineDao.getItems(routineId)

    suspend fun saveRoutine(id: Long?, name: String, items: List<RoutineExerciseEntity>) {
        db.withTransaction {
            val routineId = if (id == null) {
                routineDao.insertRoutine(RoutineEntity(name = name))
            } else {
                routineDao.updateRoutine(RoutineEntity(id = id, name = name))
                routineDao.deleteItems(id)
                id
            }
            routineDao.insertItems(items.map { it.copy(routineId = routineId) })
        }
    }

    suspend fun deleteRoutine(id: Long) {
        db.withTransaction {
            routineDao.deleteItems(id)
            routineDao.deleteRoutine(id)
        }
    }

    suspend fun saveWorkout(workout: WorkoutEntity, sets: List<SetLogEntity>) {
        db.withTransaction {
            val workoutId = workoutDao.insertWorkout(workout)
            workoutDao.insertSets(sets.map { it.copy(workoutId = workoutId) })
        }
    }
}
