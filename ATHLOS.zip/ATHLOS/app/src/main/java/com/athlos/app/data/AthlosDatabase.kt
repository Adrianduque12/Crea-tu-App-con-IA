package com.athlos.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ExerciseEntity::class,
        RoutineEntity::class,
        RoutineExerciseEntity::class,
        WorkoutEntity::class,
        SetLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AthlosDatabase : RoomDatabase() {
    abstract fun exerciseDao(): ExerciseDao
    abstract fun routineDao(): RoutineDao
    abstract fun workoutDao(): WorkoutDao

    companion object {
        fun build(context: Context): AthlosDatabase =
            Room.databaseBuilder(context.applicationContext, AthlosDatabase::class.java, "athlos.db").build()
    }
}
