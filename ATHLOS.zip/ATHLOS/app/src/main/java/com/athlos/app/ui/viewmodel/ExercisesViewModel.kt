package com.athlos.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.athlos.app.data.AthlosRepository
import com.athlos.app.data.ExerciseEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ExercisesViewModel(private val repo: AthlosRepository) : ViewModel() {
    val query = MutableStateFlow("")
    val group = MutableStateFlow<String?>(null)
    val error = MutableStateFlow<String?>(null)

    val exercises: StateFlow<List<ExerciseEntity>> = combine(repo.exercises, query, group) { list, q, g ->
        list.filter { (g == null || it.muscleGroup == g) && it.name.contains(q.trim(), ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun add(name: String, group: String, onDone: () -> Unit) {
        val clean = name.trim()
        if (clean.isEmpty()) {
            error.value = "El nombre no puede estar vacío."
            return
        }
        viewModelScope.launch {
            runCatching { repo.addExercise(clean, group) }
                .onSuccess { error.value = null; onDone() }
                .onFailure { e -> error.update { "No se pudo guardar el ejercicio." } }
        }
    }

    fun clearError() { error.value = null }
}
