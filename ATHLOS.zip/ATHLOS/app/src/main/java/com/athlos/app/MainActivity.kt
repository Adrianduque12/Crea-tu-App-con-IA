package com.athlos.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.athlos.app.ui.AthlosRoot
import com.athlos.app.ui.theme.AthlosTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AthlosTheme { AthlosRoot() }
        }
    }
}
