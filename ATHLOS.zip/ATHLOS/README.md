# ATHLOS — Gestor de entrenamientos de fuerza (Kotlin + Jetpack Compose + Room)

## Cómo abrirlo
1. Descomprime el ZIP.
2. Android Studio → File → Open → selecciona la carpeta `ATHLOS`.
3. Espera al Gradle Sync (necesita internet la primera vez; usa JDK 17, el incluido en Android Studio sirve).
4. Run ▶ en un emulador o móvil (Android 7.0+ / API 24).

## Versiones
AGP 8.5.2 · Gradle 8.9 · Kotlin 2.0.20 · KSP 2.0.20-1.0.25 · Compose BOM 2024.09.00 · Room 2.6.1 · Navigation 2.8.0
Si tu Android Studio es más antiguo/nuevo y pide actualizar AGP/Gradle, acepta la sugerencia (gradle/libs.versions.toml).

## Arquitectura
- `data/`   Room (entidades, DAOs, base de datos), `AthlosRepository` (único acceso a datos), `ProfileStore` (nombre + objetivo semanal en SharedPreferences).
- `domain/` `WorkoutCalculator` (validación y volumen = peso × repeticiones) y formateadores.
- `ui/viewmodel/` ViewModels con StateFlow (lógica separada de la interfaz).
- `ui/screens/`, `ui/components/`, `ui/theme/` Compose; navegación inferior en `ui/AthlosRoot.kt`.
- Sin Hilt, sin librerías de gráficas: la gráfica es un Canvas propio (más simple de explicar).

## Pruebas manuales rápidas
1. Ejercicios: buscar "press", filtrar por grupo, añadir uno nuevo.
2. Rutinas: crear (nombre vacío → error), añadir ejercicios, series 0 → error, guardar, editar, eliminar.
3. Entrenar: iniciar, peso "-5" → error, reps 0 → error, completar serie (arranca descanso), Finalizar sin series → error, finalizar con series → resumen.
4. Cierra y abre la app: rutinas, historial y perfil siguen ahí.
5. Progreso: sin datos → estado vacío; con datos → sesiones, volumen, récords y gráfica.
